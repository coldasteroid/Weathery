
  # Weather Dashboard UI

  This is a code bundle for Weather Dashboard UI. The original project is available at https://www.figma.com/design/CfOV5pIU7Rg3oyBfaAxTpe/Weather-Dashboard-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  