import { Sidebar } from './components/aqi/Sidebar';
import { CurrentAQI } from './components/aqi/CurrentAQI';
import { PollutantBreakdown } from './components/aqi/PollutantBreakdown';
import { AQIHistory } from './components/aqi/AQIHistory';
import { HealthRecommendations } from './components/aqi/HealthRecommendations';
import { AQIMap } from './components/aqi/AQIMap';

export default function App() {
  return (
    <div className="min-h-screen bg-[#1a1a1a] text-white p-6">
      <div className="max-w-[1400px] mx-auto">
        <div className="flex gap-6">
          {/* Sidebar */}
          <Sidebar />

          {/* Main Content */}
          <div className="flex-1 space-y-6">
            {/* Top Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Current AQI */}
              <CurrentAQI />
              
              {/* Pollutant Breakdown */}
              <div className="lg:col-span-2">
                <PollutantBreakdown />
              </div>
            </div>

            {/* Middle Section */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* AQI History */}
              <div className="lg:col-span-2">
                <AQIHistory />
              </div>

              {/* Health Recommendations */}
              <HealthRecommendations />
            </div>

            {/* Bottom Section */}
            <div className="w-full">
              <AQIMap />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
