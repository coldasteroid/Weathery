import { Search, MapPin, Calendar, CloudRain } from 'lucide-react';

export function CurrentWeather() {
  return (
    <div className="bg-[#252525] rounded-3xl p-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-blue-500/10 rounded-full blur-3xl"></div>
      
      {/* Search Icon */}
      <div className="flex justify-end mb-4">
        <button className="w-10 h-10 rounded-full bg-[#3a3a3a] hover:bg-[#4a4a4a] transition-colors flex items-center justify-center">
          <Search className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      {/* Weather Icon and Temperature */}
      <div className="relative z-10 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <div className="relative">
            <div className="w-20 h-20">
              <CloudRain className="w-20 h-20 text-gray-300" />
              <div className="absolute -right-2 top-0 w-8 h-8 bg-yellow-400 rounded-full"></div>
            </div>
          </div>
        </div>
        
        <div className="text-7xl mb-2">28°c</div>
        
        <div className="flex items-center gap-2 text-gray-400 mb-6">
          <CloudRain className="w-5 h-5" />
          <span>Rainy Storm Clouds</span>
        </div>

        {/* Location and Time */}
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-gray-400 text-sm">
            <MapPin className="w-4 h-4" />
            <span>Florida, US</span>
          </div>
          <div className="flex items-center gap-2 text-gray-400 text-sm">
            <Calendar className="w-4 h-4" />
            <span>24 July, 2022 5:01 AM</span>
          </div>
        </div>
      </div>
    </div>
  );
}
