import { CloudRain, Cloud, CloudDrizzle } from 'lucide-react';
import { LineChart, Line, ResponsiveContainer } from 'recharts';

const forecastData = [
  { day: 'Tuesday', date: '25 july', high: 29, low: 18, icon: 'rain', label: '+29°/+18' },
  { day: 'Wednesday', date: '26 july', high: 21, low: 16, icon: 'rain', label: '+21°/+16' },
  { day: 'Thursday', date: '27 july', high: 24, low: 20, icon: 'rain', label: '+24°/+20' },
  { day: 'Friday', date: '28 july', high: 30, low: 17, icon: 'cloud', label: '+30°/+17' },
];

const tomorrowData = [
  { time: 0, temp: 20 },
  { time: 1, temp: 19 },
  { time: 2, temp: 18 },
  { time: 3, temp: 19 },
  { time: 4, temp: 21 },
  { time: 5, temp: 23 },
];

export function Forecast() {
  return (
    <div className="bg-[#252525] rounded-3xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg">7 days Forecast</h2>
        <select className="bg-[#3a3a3a] text-sm px-3 py-1 rounded-lg border-none text-gray-400">
          <option>7 day</option>
          <option>14 day</option>
        </select>
      </div>

      {/* Forecast List */}
      <div className="space-y-3 mb-6">
        {forecastData.map((item, index) => (
          <div key={index} className="flex items-center justify-between py-3 px-4 bg-[#1a2332] rounded-xl">
            <div className="flex items-center gap-3">
              {item.icon === 'rain' ? (
                <CloudRain className="w-8 h-8 text-gray-300" />
              ) : (
                <Cloud className="w-8 h-8 text-gray-300" />
              )}
              <span className="text-white">{item.label}</span>
            </div>
            <div className="flex items-center gap-4 text-sm">
              <span className="text-gray-400 w-16">{item.date}</span>
              <span className="text-gray-300 w-24">{item.day}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Tomorrow Section */}
      <div className="bg-[#1a2332] rounded-xl p-4">
        <div className="flex items-center gap-3 mb-3">
          <CloudDrizzle className="w-10 h-10 text-gray-300" />
          <div>
            <div className="text-2xl">23°</div>
            <div className="text-xs text-gray-400">Thunder Storm day</div>
          </div>
        </div>
        
        <div className="text-xs text-gray-400 mb-2">Tomorrow</div>
        
        {/* Mini chart */}
        <div className="h-12 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={tomorrowData}>
              <Line
                type="monotone"
                dataKey="temp"
                stroke="#ef4444"
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}