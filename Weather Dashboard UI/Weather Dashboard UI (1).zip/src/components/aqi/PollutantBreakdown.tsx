import { PollutantCard } from './PollutantCard';
import { PollutantChart } from './PollutantChart';

const pollutants = [
  { name: 'PM2.5', value: 68, unit: 'µg/m³', level: 'Moderate', color: 'yellow', max: 150 },
  { name: 'PM10', value: 42, unit: 'µg/m³', level: 'Good', color: 'green', max: 150 },
  { name: 'O₃', value: 35, unit: 'ppb', level: 'Good', color: 'green', max: 100 },
  { name: 'NO₂', value: 18, unit: 'ppb', level: 'Good', color: 'green', max: 100 },
  { name: 'SO₂', value: 8, unit: 'ppb', level: 'Good', color: 'green', max: 100 },
  { name: 'CO', value: 0.4, unit: 'ppm', level: 'Good', color: 'green', max: 10 },
];

export function PollutantBreakdown() {
  return (
    <div className="bg-[#252525] rounded-3xl p-6">
      <h2 className="text-lg mb-4">Pollutant Breakdown</h2>
      
      {/* Pollutant Cards Grid */}
      <div className="grid grid-cols-3 gap-4 mb-6">
        {pollutants.map((pollutant, index) => (
          <PollutantCard key={index} {...pollutant} />
        ))}
      </div>

      {/* 24-Hour Trend */}
      <div className="bg-[#1a2332] rounded-2xl p-4">
        <h3 className="text-sm text-gray-400 mb-3">24-Hour AQI Trend</h3>
        <PollutantChart />
      </div>
    </div>
  );
}
