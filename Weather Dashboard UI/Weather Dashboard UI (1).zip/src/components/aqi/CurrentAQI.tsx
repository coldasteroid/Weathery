import { Search, MapPin, Calendar, Wind } from 'lucide-react';

export function CurrentAQI() {
  return (
    <div className="bg-[#252525] rounded-3xl p-6 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-yellow-500/10 rounded-full blur-3xl"></div>
      
      {/* Search Icon */}
      <div className="flex justify-end mb-4">
        <button className="w-10 h-10 rounded-full bg-[#3a3a3a] hover:bg-[#4a4a4a] transition-colors flex items-center justify-center">
          <Search className="w-5 h-5 text-gray-400" />
        </button>
      </div>

      {/* AQI Display */}
      <div className="relative z-10 mb-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-20 h-20 rounded-full bg-gradient-to-br from-yellow-400 to-orange-500 flex items-center justify-center">
            <Wind className="w-10 h-10 text-white" />
          </div>
        </div>
        
        <div className="text-7xl mb-2">68</div>
        
        <div className="flex items-center gap-2 mb-2">
          <div className="px-3 py-1 bg-yellow-500/20 rounded-full">
            <span className="text-yellow-400 text-sm">Moderate</span>
          </div>
        </div>

        <div className="text-gray-400 mb-6">Air Quality Index</div>

        {/* Location and Time */}
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-gray-400 text-sm">
            <MapPin className="w-4 h-4" />
            <span>San Francisco, CA</span>
          </div>
          <div className="flex items-center gap-2 text-gray-400 text-sm">
            <Calendar className="w-4 h-4" />
            <span>Jan 19, 2026 10:45 AM</span>
          </div>
        </div>

        {/* Main Pollutant */}
        <div className="mt-6 pt-4 border-t border-gray-700">
          <div className="text-xs text-gray-400 mb-1">Main Pollutant</div>
          <div className="text-lg">PM2.5</div>
        </div>
      </div>
    </div>
  );
}
