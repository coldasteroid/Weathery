import { LineChart, Line, XAxis, YAxis, CartesianGrid, ResponsiveContainer, Tooltip, Legend } from 'recharts';

const historyData = [
  { day: 'Mon', pm25: 42, pm10: 35, o3: 28 },
  { day: 'Tue', pm25: 48, pm10: 38, o3: 32 },
  { day: 'Wed', pm25: 55, pm10: 42, o3: 35 },
  { day: 'Thu', pm25: 68, pm10: 48, o3: 38 },
  { day: 'Fri', pm25: 72, pm10: 52, o3: 42 },
  { day: 'Sat', pm25: 65, pm10: 45, o3: 38 },
  { day: 'Sun', pm25: 58, pm10: 40, o3: 35 },
];

export function AQIHistory() {
  return (
    <div className="bg-[#252525] rounded-3xl p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-lg">7-Day History</h2>
        <select className="bg-[#3a3a3a] text-sm px-3 py-1 rounded-lg border-none text-gray-400">
          <option>Last 7 days</option>
          <option>Last 14 days</option>
          <option>Last 30 days</option>
        </select>
      </div>

      {/* Chart */}
      <div className="h-[300px] w-full">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={historyData}>
            <CartesianGrid strokeDasharray="3 3" stroke="#2a3a4a" />
            <XAxis 
              dataKey="day" 
              stroke="#6b7280"
              style={{ fontSize: '12px' }}
            />
            <YAxis 
              stroke="#6b7280"
              style={{ fontSize: '12px' }}
            />
            <Tooltip 
              contentStyle={{ 
                backgroundColor: '#1a2332', 
                border: '1px solid #2a3a4a',
                borderRadius: '8px'
              }}
            />
            <Legend 
              wrapperStyle={{ fontSize: '12px' }}
            />
            <Line 
              type="monotone" 
              dataKey="pm25" 
              stroke="#eab308" 
              strokeWidth={2}
              name="PM2.5"
              dot={{ r: 4 }}
            />
            <Line 
              type="monotone" 
              dataKey="pm10" 
              stroke="#3b82f6" 
              strokeWidth={2}
              name="PM10"
              dot={{ r: 4 }}
            />
            <Line 
              type="monotone" 
              dataKey="o3" 
              stroke="#10b981" 
              strokeWidth={2}
              name="O₃"
              dot={{ r: 4 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </div>

      {/* AQI Scale Reference */}
      <div className="mt-6 pt-4 border-t border-gray-700">
        <div className="text-xs text-gray-400 mb-2">AQI Scale</div>
        <div className="flex items-center gap-2">
          <div className="flex-1 flex items-center gap-2">
            <div className="w-12 h-3 bg-green-500 rounded"></div>
            <span className="text-xs text-gray-400">0-50 Good</span>
          </div>
          <div className="flex-1 flex items-center gap-2">
            <div className="w-12 h-3 bg-yellow-500 rounded"></div>
            <span className="text-xs text-gray-400">51-100 Moderate</span>
          </div>
          <div className="flex-1 flex items-center gap-2">
            <div className="w-12 h-3 bg-orange-500 rounded"></div>
            <span className="text-xs text-gray-400">101-150 Unhealthy</span>
          </div>
          <div className="flex-1 flex items-center gap-2">
            <div className="w-12 h-3 bg-red-500 rounded"></div>
            <span className="text-xs text-gray-400">151+ Hazardous</span>
          </div>
        </div>
      </div>
    </div>
  );
}
