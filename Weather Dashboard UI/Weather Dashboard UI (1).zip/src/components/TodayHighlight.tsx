import { Wind, Sun, Droplets, Eye, Thermometer } from 'lucide-react';
import { WindChart } from './WindChart';
import { UVIndexGauge } from './UVIndexGauge';
import { SunriseSunset } from './SunriseSunset';

export function TodayHighlight() {
  return (
    <div className="bg-[#252525] rounded-3xl p-6">
      <h2 className="text-lg mb-4">Today's Highlight</h2>
      
      {/* Top Row - 3 Main Cards */}
      <div className="grid grid-cols-3 gap-4 mb-4">
        {/* Wind Status */}
        <div className="bg-[#1a2332] rounded-2xl p-4">
          <div className="flex items-center justify-between mb-3">
            <span className="text-sm text-gray-400">Wind Status</span>
          </div>
          <WindChart />
          <div className="mt-3">
            <span className="text-2xl">7.90</span>
            <span className="text-sm text-gray-400 ml-1">km/h</span>
          </div>
          <div className="text-xs text-gray-500 mt-1">5:01 AM</div>
        </div>

        {/* UV Index */}
        <div className="bg-[#1a2332] rounded-2xl p-4">
          <span className="text-sm text-gray-400 mb-3 block">UV Index</span>
          <UVIndexGauge value={5.5} />
          <div className="text-center mt-2">
            <span className="text-2xl">5.50</span>
            <span className="text-sm text-gray-400 ml-1">UV</span>
          </div>
        </div>

        {/* Sunrise & Sunset */}
        <div className="bg-[#1a2332] rounded-2xl p-4">
          <span className="text-sm text-gray-400 mb-3 block">Sunrise & Sunset</span>
          <SunriseSunset />
        </div>
      </div>

      {/* Bottom Row - 3 Small Cards */}
      <div className="grid grid-cols-3 gap-4">
        {/* Humidity */}
        <div className="bg-[#1a2332] rounded-2xl p-4">
          <span className="text-sm text-gray-400 block mb-2">Humidity</span>
          <div className="flex items-end gap-2">
            <Droplets className="w-5 h-5 text-blue-400 mb-1" />
            <span className="text-3xl">84</span>
          </div>
          <div className="text-xs text-gray-500 mt-2">The dew point is 7° right now.</div>
        </div>

        {/* Visibility */}
        <div className="bg-[#1a2332] rounded-2xl p-4">
          <span className="text-sm text-gray-400 block mb-2">Visibility</span>
          <div className="flex items-end gap-2">
            <Eye className="w-5 h-5 text-blue-400 mb-1" />
            <span className="text-3xl">03</span>
            <span className="text-sm text-gray-400 mb-1">km</span>
          </div>
          <div className="text-xs text-gray-500 mt-2">Haze is affecting visibility.</div>
        </div>

        {/* Feels Like */}
        <div className="bg-[#1a2332] rounded-2xl p-4">
          <span className="text-sm text-gray-400 block mb-2">Feels Like</span>
          <div className="flex items-end gap-2">
            <Thermometer className="w-5 h-5 text-orange-400 mb-1" />
            <span className="text-3xl">42°</span>
          </div>
          <div className="text-xs text-gray-500 mt-2">Humidity is making it feel hotter.</div>
        </div>
      </div>
    </div>
  );
}
